from solidspy import solids_GUI

UC, E_nodes, S_nodes = solids_GUI(compute_strains = True)


